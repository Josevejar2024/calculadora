﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculadora.Clases
{
    internal class ClsResta
    {
        public double Restar(double N1, double N2)
        {
            double R;
            R = N1 - N2;
            return R;
        }
    }
}
