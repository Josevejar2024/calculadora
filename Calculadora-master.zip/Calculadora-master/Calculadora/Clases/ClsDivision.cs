﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculadora.Clases
{
    internal class ClsDivision
    {
        public double Dividir(double N1, double N2)
        {
            double D;
            D = N1 / N2;
            return D;
        }
    }
}
